using CoffeeMachineLibrary;

namespace TestCoffeeMachine
{
    [TestClass]
    public class CoffeeMachineTesting
    {
        [TestMethod]
        public void CoinValueGettingSumOfCoins()
        {
            double expectedResult = 2.60;
            double firstCoin = 1.00;
            double secondCoin = 1.00;
            double thirdCoin = 0.50;
            double forthCoin = 0.10;

            CoffeeMachine coinValue = new CoffeeMachine();
            Assert.AreEqual(expectedResult, coinValue.CoinValue(firstCoin, secondCoin, thirdCoin, forthCoin));
        }


        [TestMethod]
        public void CoinInfoSetCorrectCoinValuesReturnInfo()
        {
            double totalMoney = 2.60;
            double firstCoin = 1.00;
            double secondCoin = 1.00;
            double thirdCoin = 0.50;
            double forthCoin = 0.10;
            string expectedResult = "The used coin values are " + firstCoin.ToString() + " " + secondCoin.ToString() + " " + thirdCoin.ToString() + " " + forthCoin.ToString()
            + "The total is " + totalMoney;

            CoffeeMachine coinInfo = new CoffeeMachine();
            Assert.AreEqual(expectedResult, coinInfo.CoinInfo(firstCoin, secondCoin, thirdCoin, forthCoin));
        }

        [TestMethod]
        public void GetProductSetMoneyRangeForCapuchinoReturnCapuchino()
        {
            double firstCoin = 1.00;
            double secondCoin = 0.50;
            double thirdCoin = 0.50;
            double forthCoin = 0.10;
            string productLatte = "Latte";
            double lattePrice = 2.50;
            string productCapuchino = "Capuchino";
            double capuchinoPrice = 1.50;
            string expectedResult = "Capuchino";
            string notEnoughMoney = "No Money";

            CoffeeMachine getProduct = new CoffeeMachine();
            Assert.AreEqual(expectedResult, getProduct.GetProduct(firstCoin, secondCoin, thirdCoin, forthCoin, productLatte, lattePrice, productCapuchino, capuchinoPrice, notEnoughMoney));
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetChangeMoneyTooLowThrowArgumentException()
        {
            double firstCoin = 0.10;
            double secondCoin = 0.50;
            double thirdCoin = 0.50;
            double forthCoin = 0.10;
            string productLatte = "Latte";
            double lattePrice = 2.50;
            string productCapuchino = "Capuchino";
            double capuchinoPrice = 1.50;
            double expectedResult = 1.20;
            string notEnoughMoney = "No Money";

            CoffeeMachine getChange = new CoffeeMachine();
            getChange.GetChange(firstCoin, secondCoin, thirdCoin, forthCoin, productLatte, lattePrice, productCapuchino, capuchinoPrice);
        }

        [TestMethod]
        public void CoinValueInputNegativeValueReturningPositive()
        {
            double expectedResult = 2.60;
            double firstCoin = 1.00;
            double secondCoin = 1.00;
            double thirdCoin = -0.50;
            double forthCoin = -0.10;

            CoffeeMachine coinValue = new CoffeeMachine();
            Assert.AreEqual(expectedResult, coinValue.CoinValue(firstCoin, secondCoin, thirdCoin, forthCoin));
        }
    }
}